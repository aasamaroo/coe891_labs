/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q3;

/**
 *
 * @author aasamaro
 */
public class Calculation {
    public static int findMax(int arr[]){
        //Issue before was that max was equal to 0
        //simple fix would be to just make max some large negative number initially
        int max = -999;
        for(int i = 1; i < arr.length; i++){
            if(max < arr[i]){
                max = arr[i];
            }
        }
        return max;
    }
    
    public static int cube(int n){
        return n*n*n;
    }
}
