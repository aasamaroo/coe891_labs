/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q3;

import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class CalculationTest {
    
    private Calculation calc;
    
    @BeforeClass
    public static void before(){
        System.out.println("Before Class");
    }
    
    @Before
    public void setup1(){
        calc = new Calculation();
        System.out.println("Before Test");
    }
    
    @Test
    public void testFindMax() {
        // TODO review the generated test code and remove the default call to fail.
        System.out.println("Testing Find Max Function");
        assertEquals(-2, calc.findMax(new int[]{-12, -3, -4, -2}));
    }
    
    
    @Test
    public void testCube(){
        System.out.println("Testing Cube Function");
        assertEquals(8, calc.cube(2));
    }
    
    @After
    public void afterTest(){
        System.out.println("After Test");
    }
    
    @AfterClass
    public static void after(){
        System.out.println("After Class");
    }
}
