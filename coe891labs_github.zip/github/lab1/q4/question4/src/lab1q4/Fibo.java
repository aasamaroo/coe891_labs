/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q4;

/**
 *
 * @author aasamaro
 */
public class Fibo {
    public static int fibonacci(int number){
        
        int prevprev, prev = 0, current = 1;
        
        if(number >= 0){
            
            if (number == 1 || number == 2) {
                return 1;
            }else if(number == 0){
                return 0;
        }
            for(int i = 0; i < number; i++){
                prevprev = prev;
                prev = current;
                current = prevprev + prev;
            }
            return current;
        } else return -1; //return -1 which we can create a test case for in
                          //case the user inputs a negative number
    }
}
