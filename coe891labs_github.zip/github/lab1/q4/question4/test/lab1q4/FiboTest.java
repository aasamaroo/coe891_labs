/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q4;

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

/**
 *
 * @author aasamaro
 */
public class FiboTest {
    
    
    private Fibo f;
    
    public FiboTest() {
    }
    
    //Prints message to signal beginning of tests
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Before Class\n");
    }
    
    //Prints message to signal end of tests
    @AfterClass
    public static void tearDownClass() {
        System.out.println("After Class");
    }
    
    /**
     *Before method which will initialize a new fibonacci object
     *before each test
    */
    @Before
    public void setUp(){
        System.out.println("Creating new Fibo Object");
        f = new Fibo();
        System.out.println("Test Begin\n");
    }
    
    /**
     * After method which will remove the previously used Fibo object
     * after each test is completed
     */
    @After
    public void cleanUp(){
        System.out.println("Test Finished\nDeleting Fibo Object\n");
        f = null;
    }

    
    /**
     * Test Fibonacci method when input is negative
     */
    @Test
    public void testZero(){
        System.out.println("Testing Input = 0\n");
        int number = 0;
        int expResult = 0;
        int result = f.fibonacci(number);
        assertEquals(expResult, result);
    }
    
    /**
     * Test Fibonacci method when input is 0
     */
    @Test
    public void testNeg(){
        System.out.println("Testing Negative Input\n");
        int number = -9;
        int expResult = -1;
        int result = f.fibonacci(number);
        assertEquals(expResult, result);
    }
    
    
    /**
     * Test Fibonacci method when input is 1
     */
    @Test
    public void testOne() {
        System.out.println("Testing Input = 1\n");
        int number = 1;
        int expResult = 1;
        int result = f.fibonacci(number);
        assertEquals(expResult, result);
        
    }
    
    /**
     * Test Fibonacci when a positive number is used like normally
     */
    @Test
    public void testFibo(){
        System.out.println("Testing Input = 6\n");
        int number = 6;
        int expResult = 13;
        int result = f.fibonacci(number);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testOneAndTwo(){
        System.out.println("Testing Inputs 1 and 2 to make sure they're the same\n");
        int number1 = 1;
        int number2 = 2;
        int result1 = f.fibonacci(number1);
        int result2 = f.fibonacci(number2);
        assertEquals(result1, result2);
    }
    
    
}
