/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe891lab1;

import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class CalculationTest {
    
    public CalculationTest() {
    }
    

    @Test
    public void testFindMax() {
        // TODO review the generated test code and remove the default call to fail.
        assertEquals(4, Calculation.findMax(new int[]{1, 3, 4, 2}));
    }
    
}
