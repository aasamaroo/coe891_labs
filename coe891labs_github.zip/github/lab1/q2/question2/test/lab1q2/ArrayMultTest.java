/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q2;

import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class ArrayMultTest {
    
    private ArrayMult am;
    private int[] array1 = {1, 2, 3, 4};
    private int[] array2 = {1, 2, 3, 4, 5, 6, 7};
    private int [] expected = {1, 4, 9, 16, 5, 6, 7};
    
    @Before
    public void setUp() {
        am = new ArrayMult();
    }
    

    @Test
    public void testMult() {
        int [] outArray = am.mult(array1, array2);
        for(int i = 0; i < expected.length; i++){
            assertEquals(expected[i], outArray[i]);
        }
    }
    
}
