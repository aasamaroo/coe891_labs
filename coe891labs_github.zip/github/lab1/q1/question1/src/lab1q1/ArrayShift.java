/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q1;

/**
 *
 * @author aasamaro
 */
public class ArrayShift {
    
    public int[] shiftOne(int[] inArray){
        int[] outArray = new int[inArray.length];
        int shift = 1;
        for(int i = 0; i < inArray.length; i++){
            //copy i'th element from inArray to i+1 slot in outArray
            outArray[i] = inArray[(shift + i) % inArray.length];
        }
        //set first element of outArray to -1
        outArray[0] = -1;
        
        return outArray;
    }
    
}
