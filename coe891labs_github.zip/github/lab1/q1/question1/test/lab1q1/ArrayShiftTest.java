/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1q1;

import org.junit.*;
import static org.junit.Assert.*;



/**
 *
 * @author aasamaro
 */
public class ArrayShiftTest  {
    
    private ArrayShift as;
    private int[] inArray = {4, 6, 0, 3, 4, 5, 4, 4, 6, 2};
    
    
    @Before
    public final void setUp(){
        as = new ArrayShift();
    }
    
    @Test
    public void testShiftOne(){
        int[] outArray = as.shiftOne(inArray);
        //need to add some test cases (3 total)
        //test length of inArray = length of outArray
        assertEquals(outArray.length, inArray.length);
        //test first element = -1
        assertEquals(-1, outArray[0]);
        //test that all but the last element from inArray is in outArray
        for(int k = 1; k < inArray.length-1; k++){
            assertEquals(inArray[k+1], outArray[k]);
        }
    }
    
}
