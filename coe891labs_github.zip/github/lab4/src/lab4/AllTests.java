package lab4;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.junit.*;

@RunWith(Suite.class)
@SuiteClasses({ TriclassTest.class, TriclassTestTwo.class })
public class AllTests {

	public static int testNo = 1;
	
	@BeforeClass
	public static void testingStarted(){
		System.out.println("Testing Started\n");
	}
	
	@AfterClass
	public static void testingFinished(){
		System.out.println("Testing finished\n");
	}
	
	@Before
	public void beforeTest(){
		System.out.println("Test " + testNo + " started\n");
	}
	
	@After
	public void afterTest(){
		System.out.println("Test " + testNo + " finished\n");
		testNo++;
	}
}
