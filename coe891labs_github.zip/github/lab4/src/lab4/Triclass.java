package lab4;

public class Triclass {
	
	
	public static boolean checkZero(int a, int b, int c){
		if(a == 0 || b == 0 || c == 0){
			return true;
		} else return false;
	}
	
	public static int classify(int a, int b, int c) {
		
		int result = 0;
		
		if(checkZero(a,b,c)){
			result = 0;
			return result;
		}
		
        if(a >= (b+c) || c >= (b+a) || b >= (a+c) ) {
            result = 0; //not a triangle
        } else if(a==b && b==c) {
            result = 1; //equilateral
        } else if(a!=b && b!=c && c!=a) {
            result = 2; //scalene
        } else if ((a==b && b!=c ) || (a!=b && c==a) || (c==b && c!=a)) {
            result = 3; //isoceles
        }
        return result;
    }
	
}
