package lab4;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.*;



public class TriclassTestTwo {
	
	public static int testNo = 11;
	private Triclass t;
	
	
	

	@Before
	public void setUp() throws Exception {
		System.out.println("Test " + testNo + " started\n");
		t = new Triclass();
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Test " + testNo + " finished\n");
		testNo = testNo + 1;
		t = null;
	}
	
	public static void printResult(int x){
		switch (x){
		case 0:
			System.out.println("Invalid\n");
			break;
		case 1:
			System.out.println("Equilateral\n");
			break;
		case 2:
			System.out.println("Scalene\n");
			break;
		case 3:
			System.out.println("Isoceles\n");
			break;
		}
			
	}

	//Test just to make sure that 0 cannot be used as an input
	@Test
	public void testZero() {
		int result = t.classify(0, 2, 3);
		int expected = 0;
		printResult(result);
		assertEquals(expected, result);
	}

	
	//test for scalene triangle
	@Test
	public void testSca(){
		int result = t.classify(4, 5, 6);
		int expected = 2;
		printResult(result);
		assertEquals(expected, result);
	}
	

	
}
