package lab4;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class TriclassTest {
	
	public static int testNo = 1;
	private Triclass t;
	private int s3, exp;
	
	public TriclassTest(Integer s3, Integer exp){
		this.s3 = s3;
		this.exp = exp;
	}
	
	@Parameterized.Parameters
    public static Collection sides(){
        return Arrays.asList(new Object[][] {{1,3}, {2,3}, {3,3}, {4,3}, {5,1}, {6,3}, {7,3}, {8,3}, {9,3}, {10,0}});
    }

	@Before
	public void setUp() throws Exception {
		t = new Triclass();
		System.out.println("Test " + testNo + " started\n");
	}

	@After
	public void tearDown() throws Exception {
		t = null;
		System.out.println("Test " + testNo + " finished\n");
		testNo = testNo + 1;
	}
	
	public static void printResult(int x){
		switch (x){
		case 0:
			System.out.println("Invalid\n");
			break;
		case 1:
			System.out.println("Equilateral\n");
			break;
		case 2:
			System.out.println("Scalene\n");
			break;
		case 3:
			System.out.println("Isoceles\n");
			break;
		}
			
	}

	//Test just to make sure that 0 cannot be used as an input
	/*
	@Test
	public void testZero() {
		int result = t.classify(0, 2, 3);
		int expected = 0;
		printResult(result);
		assertEquals(expected, result);
	}
	*/
	/*
	//test for equilateral triangle
	@Test
	public void testEq(){
		int result = t.classify(5, 5, 5);
		int expected = 1;
		assertEquals(expected, result);
	}
	*/
	
	//test for scalene triangle
	/*
	@Test
	public void testSca(){
		int result = t.classify(4, 5, 6);
		int expected = 2;
		printResult(result);
		assertEquals(expected, result);
	}
	*/
	/*
	//test for isoceles triangle
	@Test
	public void testIso(){
		int result = t.classify(5, 5, 6);
		int expected = 3;
		assertEquals(expected, result);
	}
	*/
	
	//Parameterized test where 2 sides are set to 5, and the rest are variable
	@Test
	public void testFive(){
		int result = t.classify(5, 5, s3);
		printResult(result);
		assertEquals(exp, result);
	}

}
