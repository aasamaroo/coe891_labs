/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author aasamaro
 */
@RunWith(Parameterized.class)
public class PrimeNumberCheckerTest {
    
    private Integer inputNum;
    private Boolean expRes;
    private PrimeNumberChecker checker;
    
    public PrimeNumberCheckerTest(Integer inputNum, Boolean expRes){
        this.inputNum = inputNum;
        this.expRes = expRes;
    }
    
    @Parameterized.Parameters
    public static Collection primeNums(){
        return Arrays.asList(new Object[][] {{2,true}, {6,false}, {19,true}, {22,false}, {23,true}});
    }
    
    @BeforeClass
    public static void startTesting(){
        System.out.println("The tests have begun\n");
    }
    
    @AfterClass
    public static void finishTesting(){
        System.out.println("The tests have been completed\n");
    }
    
    @Before
    public void setupTest(){
        checker = new PrimeNumberChecker();
    }
    
    @After
    public void cleanupTest(){
        checker = null;
    }
    
    @Test
    public void testPrimeNumber(){
        System.out.println("Testing input: " + inputNum + "\n");
        assertEquals(expRes, checker.validate(inputNum));
    }
    
    
}
