/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question4;

import java.util.*;

/**
 *
 * @author aasamaro
 */
public class Fibo {
    public static int compute(int n){
        int result = 0;
        if(n <= 1){
            result = n;
        } else {
            result = compute(n - 1) + compute(n - 2);
        }
        return result;
    }
}
