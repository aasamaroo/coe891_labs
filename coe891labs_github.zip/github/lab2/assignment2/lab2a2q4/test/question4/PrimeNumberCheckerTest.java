/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question4;

import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import static org.junit.Assume.*;
import org.junit.experimental.theories.*;
import org.junit.runner.RunWith;
import org.junit.experimental.theories.suppliers.*;


/**
 *
 * @author aasamaro
 */
@RunWith(Theories.class)
public class PrimeNumberCheckerTest {
    

    private PrimeNumberChecker checker;
    
    
    
    
    
    @BeforeClass
    public static void startTesting(){
        System.out.println("The tests have begun\n");
    }
    
    @AfterClass
    public static void finishTesting(){
        System.out.println("The tests have been completed\n");
    }
    
    @Before
    public void setupTest(){
        checker = new PrimeNumberChecker();
    }
    
    @After
    public void cleanupTest(){
        checker = null;
    }
    
    @DataPoints
    public static int [] values = {2, 7, 6, 19, 22, 23};
    
    @Theory
    public void testPrimeNumber(int n){
        System.out.println("Testing input " + n);
        assumeTrue(n > 0);
        assertEquals(true, checker.validate(n));
    }
    
    
}
