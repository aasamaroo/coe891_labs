/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question4;

import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import static org.junit.Assume.*;
import org.junit.runner.RunWith;
import org.junit.experimental.theories.*;
import org.junit.experimental.theories.suppliers.*;

/**
 *
 * @author aasamaro
 */
@RunWith(Theories.class)
public class FiboTest {
    
    /*
    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {{0,0}, {1,1}, {2,1}, {3,2}, {4,3}, {5,5}, {6,8}});
    }
    
    private int fiboInput, fiboExpected;
    
    
    public FiboTest(int input, int expected) {
        this.fiboInput = input;
        this.fiboExpected = expected;
    }
    */
    
    private Fibo f;
    
    @BeforeClass
    public static void beforeClass(){
        System.out.println("This test case will test a Fibonacci sequence using JUnit Theories.\n");
    }
    
    @AfterClass
    public static void afterClass(){
        System.out.println("All tests have been completed.\n");
    }
    
    @Before
    public void beforeTest(){
        
        f = new Fibo();
    }
    
    @After
    public void afterTest(){
        System.out.println("Finished test.\n");
        f = null;
    }
    
  
   @DataPoints
    public static int[] VALUES = { 0, 1, 2, 3, 4, 5, 6 };

    @Theory
    public void seeds(int n) {
        assumeTrue(n <= 1);
        System.out.println("Testing " + n);
        assertEquals(n, f.compute(n));
    }

    @Theory
    public void recurrence(int n) {
        System.out.println("Testing " + n);
        assumeTrue(n > 1);
        assertEquals(f.compute(n - 1) + f.compute(n - 2), f.compute(n));
    }


}
