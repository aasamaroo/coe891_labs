/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import java.util.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author aasamaro
 */
@RunWith(value = Parameterized.class)
public class FiboTest {
    
    
    @Parameterized.Parameters
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {{0,0}, {1,1}, {2,1}, {3,2}, {4,3}, {5,5}, {6,8}});
    }
    
    private int fiboInput, fiboExpected;
    
    
    public FiboTest(int input, int expected) {
        this.fiboInput = input;
        this.fiboExpected = expected;
    }
    
    @BeforeClass
    public static void beforeClass(){
        System.out.println("This test case will test a Fibonacci sequence using parameterized testing.\n");
    }
    
    @AfterClass
    public static void afterClass(){
        System.out.println("All tests have been completed.\n");
    }
    
    @Before
    public void beforeTest(){
        System.out.println("Testing input " + fiboInput + " with expected output " + fiboExpected + ":\n");
    }
    
    @After
    public void afterTest(){
        System.out.println("Finished test.\n");
    }
  
   @Test
    public void test() {
        assertEquals(fiboExpected, Fibo.compute(fiboInput));
    }
  

}
