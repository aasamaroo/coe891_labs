/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import org.junit.*;
import static org.junit.Assert.*;
import static org.junit.Assume.*;
import org.junit.experimental.theories.*;
import org.junit.runner.RunWith;

/**
 *
 * @author aasamaro
 */
@RunWith(Theories.class)
public class TheoriesTest {
    
    @DataPoints
    public static int[] integers(){
        return new int[]{1, 2, 307, 400567};
    }
    
    @DataPoints
    public static int[] moreIntegers(){
        return new int[]{0, -1, -10, -1234, 1, 10, 6789};
    }
    
    @DataPoints
    public static int[] evenMoreIntegers(){
        return new int[]{0, -1, -10, -1234, 1, 10, 6789, Integer.MAX_VALUE, Integer.MIN_VALUE};
    }
    
    @Theory
    public void a_plus_b_is_greater_than_a_and_greater_than_b(Integer a, Integer b) {
    assumeTrue(a > 0);
    assumeTrue(b > 0);
    assertTrue(a + b > a);
    assertTrue(a + b > b);
  }
    @Theory
    public void addition_is_commutative(Integer a, Integer b) {
    assertTrue(a + b == b + a);
  }
}
