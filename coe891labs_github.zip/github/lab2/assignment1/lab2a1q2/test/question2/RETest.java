/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class RETest {
    
    public RETest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("Testing phone number validator");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Finished phone number validator testing");
    }
    

    /**
     * Test of checkPhoneNumber method, of class RE.
     */
    @Test
    public void testCheckPhoneNumber() {
        System.out.println("Check 10 consecutive digits");
        String s = "1234567890";
        System.out.println(s);
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
        
    }


    
    @Test
    public void testBrackets(){
        System.out.println("Check using brackets at start");
        String s = "(123) 456-7890";
        System.out.println(s);
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testExt(){
        System.out.println("Check using extensions");
        String s = "123-456-7890 ext4444";
        System.out.println(s);
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
    }
    
}
