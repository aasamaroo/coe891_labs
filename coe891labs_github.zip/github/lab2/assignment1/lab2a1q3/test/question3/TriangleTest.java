/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;


import org.junit.*;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class TriangleTest {
    
    
    private Triangle t1, t2, t3, t4, t5; 
    
    public TriangleTest() {
    }
    
    private boolean tIsValid(Triangle t){
        
        boolean result;
        if(t.s1 > 0 && t.s2 > 0 && t.s3 > 0){
            if (t.s1 + t.s2 <= t.s3 || t.s1 + t.s3 <= t.s2 || t.s2 + t.s3 <= t.s1){
                result = false;
            }else{
                result = true;
         }   
        } else {
            result = false;
        }    
        
        return result;
    }
    
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("------------------------------------------------------\n" + "This class is for testing the Triangle.java methods\n");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("All of the tests have been completed\n"+"------------------------------------------------------\n");
    }
    
    //Before method to create new triangles before tests
    @Before
    public void prepTest(){
        System.out.println("Creating new triangles\n");
        t1 = new Triangle(3, 4, 5);
        t2 = new Triangle(5, 4, 3);
        t3 = new Triangle(8, 5, 5);
        t4 = new Triangle(3, 4, 100);
        t5 = new Triangle(-3, 4, 5);
    }
    
    //After method to clean up used triangles after tests
    @After
    public void cleanUp(){
        System.out.println("Cleaning up triangles\n");
        t1 = null;
        t2 = null;
        t3 = null;
        t4 = null;
        t5 = null;
    }
    
    
    //Test method for triangle 1
    @Test
    public void testCalcArea1() {
        System.out.println("Testing area of triangle 1\n");
        if(tIsValid(t1)){
            double result = 6.0;
            assertEquals(result, t1.calcArea(), 0);
        } else{
            fail("Triangle is not valid");
        }
    }
    
    //Test method for triangle 2
    @Test
    public void testCalcArea2(){
        System.out.println("Testing area of triangle 2\n");
        if(tIsValid(t2)){
            double result = 6.0;
            assertEquals(result, t2.calcArea(), 0);
        } else{
            fail("Triangle is not valid");
        }
    }
    
    //Test method for traingle 3
    @Test
    public void testCalcArea3(){
        System.out.println("Testing area of triangle 3\n");
        if(tIsValid(t3)){
            double result = 12.0;
            assertEquals(result, t3.calcArea(), 0);
        } else{
            fail("Triangle is not valid");
        }
    }
    
    //Test method to compare the areas of trangles 1 and 2
    @Test
    public void comparet1t2(){
        System.out.println("Comparing areas of triangles 1 and 2\n");
        if(tIsValid(t1) && tIsValid(t2)){
            assertEquals(t1.calcArea(), t2.calcArea(), 0);
        } else{
            fail("Triangle is not valid");
        }
    }
    
    //Test method to show invalid input triangle with sides 3, 4, and 100
    
    //This triangle is INVALID because the sum of 2 sides is not always greater
    //than the third (3+4 is NOT greater than 100)
    
    @Test
    public void testInvalidTriangle(){
        System.out.println("Testing invalid triangle 4\n");
        assertFalse(tIsValid(t4));
    }
    
    
    //Test method to show invalid input when someone enters a triangle with
    //A negative number 
   
    @Test
    public void testNeg(){
        System.out.println("Test invalid triangle 5\n");
        assertFalse(tIsValid(t5));
    }
}
