/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aasamaro
 */
public class RETest {
    
    public RETest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
        System.out.println("------------------------------------------------------\n" + "Testing phone number validator\n");
    }
    
    @AfterClass
    public static void tearDownClass() {
        System.out.println("Finished phone number validator testing\n"+"------------------------------------------------------\n");
    }
    

    /**
     * Test of checkPhoneNumber method, of class RE.
     */
    @Test
    public void testCheckPhoneNumber() {
        System.out.println("Check 10 consecutive digits\n");
        String s = "1234567890";
        System.out.println(s + "\n");
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
        
    }


    
    @Test
    public void testBrackets(){
        System.out.println("Check using brackets at start\n");
        String s = "(123) 456-7890";
        System.out.println(s + "\n");
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testExt(){
        System.out.println("Check using extensions\n");
        String s = "123-456-7890 ext4444";
        System.out.println(s + "\n");
        boolean expResult = true;
        boolean result = RE.checkPhoneNumber(s);
        assertEquals(expResult, result);
    }
    
}
