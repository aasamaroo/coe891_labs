/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

import java.util.*;
import java.util.regex.*;
/**
 *
 * @author aasamaro
 */
public class RE {
    
    public static boolean checkPhoneNumber(String s){
        
        //validates phone numbers having 10 digits (xxxxxxxxxx)  
if (s.matches("\\d{10}"))  
return true;  
//validates phone numbers having digits, -, . or spaces  
else if (s.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}"))  
return true;  
else if (s.matches("\\d{4}[-\\.\\s]\\d{3}[-\\.\\s]\\d{3}"))  
return true;  
//validates phone numbers having digits and extension (length 3 to 5)  
else if (s.matches("\\d{3}-\\d{3}-\\d{4}\\s(x|(ext))\\d{3,5}"))  
return true;  
//validates phone numbers having digits and area code in round brackets  
else if (s.matches("\\(\\d{3}\\)-\\d{3}-\\d{4}"))  
return true;  
//validates phone numbers having digits and area code in round brackets  
else if (s.matches("\\(\\d{3}\\)[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}"))  
return true;
else if (s.matches("\\(\\d{5}\\)-\\d{3}-\\d{3}"))  
return true;  
else if (s.matches("\\(\\d{4}\\)-\\d{3}-\\d{3}"))  
return true;  
//return false if any of the input matches is not found  
else  
return false;  
    }
    
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter phone number: ");
        String input = sc.nextLine();
        boolean wasPhoneNum = checkPhoneNumber(input);
        System.out.println("\nThat was" + (wasPhoneNum? "" : "n't")+" a phone number.");
    }
}
