/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question3;

//imports
import java.util.*;

/**
 *
 * @author aasamaro
 */
public class Triangle {
    
    
    public int s1, s2, s3;
    
    public Triangle(int s1, int s2, int s3){
        this.s1 = s1;
        this.s2 = s2;
        this.s3 = s3;
    }
    
    /*
    Method to calculate area of triangle using Heron's formula
    This is INCORRECT because the equation should be
    sqrt(s*(s-s1)*(s-s2)*(s-s3))
    In this case, it has been flipped, and we need to debug it using JUnit
    */
    public double calcArea(){
        //calculate semiperimeter
        double s = (s1 + s2 + s3) * 0.5;
        
        System.out.println("\t s= " + s);
        
        //incorrect implementation of calculation (results in failed tests)
        //double result = Math.sqrt(s * (s1 - s) * (s2 - s) * (s3 - s));
        
        //correct implementation of tests (tests pass)
        double result = Math.sqrt(s * (s - s1) * (s - s2) * (s - s3));
        
        System.out.println("\t result = " + result + "\n");
        return result;
    }
    
}
