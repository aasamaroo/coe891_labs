package lab5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PartSeven {
	public String baseUrl = "http://www.linkedin.com";
	String driverPath = "geckodriver";
	public WebDriver driver;
	
	//throwaway linkedin account I made for this lab
	public String email = "justaprankbro889@gmail.com";
	public String password = "A1!B2.C3";
	
	@BeforeTest
	  public void launchBrowser(){
		  System.out.println("Launching Firefox\n");
		  System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get(baseUrl);
	  }
	
	@AfterTest
	  public void terminateBrowser() {
		  //driver.close();
	  }
	
	@Test(priority = 0)
	public void loginToLinkedIn(){
		driver.findElement(By.id("session_key")).sendKeys(email);
		driver.findElement(By.id("session_password")).sendKeys(password);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);}
	}
	
	@Test(priority=1)
	public void checkFeed(){
		String expUrl = "https://www.linkedin.com/feed/";
		String actualUrl = driver.getCurrentUrl();
		Assert.assertEquals(expUrl, actualUrl);
		try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);}
	}
}
