package lab5;

import org.testng.annotations.Test;

public class TestNG_Priority_Annotations {
  @Test
  public void c_method() {
	  System.out.println("Method C\n");
  }
  
  @Test
  public void b_method(){
	  System.out.println("Method B");
  }
  
  @Test(priority=6)
  public void a_method(){
	  System.out.println("Method A\n");
  }
  
  @Test(priority=0)
  public void e_method(){
	  System.out.println("Method E\n");
  }
  
  @Test(priority=6)
  public void d_method(){
	  System.out.println("Method D\n");
  }
}
