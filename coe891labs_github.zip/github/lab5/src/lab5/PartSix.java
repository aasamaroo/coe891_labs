package lab5;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.*;

public class PartSix {
	
	String driverPath = "geckodriver";
	public WebDriver driver;
	
	@Test
	public void executeSessionOne(){
		  System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get("http://demo.guru99.com/V4/");
		  driver.findElement(By.name("uid")).sendKeys("Driver 1");
	}
	
	@Test
	public void executeSessionTwo(){
		System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get("http://demo.guru99.com/V4/");
		  driver.findElement(By.name("uid")).sendKeys("Driver 2");
	}
	
	@Test
	public void executeSessionThree(){
		System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get("http://demo.guru99.com/V4/");
		  driver.findElement(By.name("uid")).sendKeys("Driver 3");
	}
	
	@AfterTest
	public void closeConnection(){
		//driver.close();
	}
}
