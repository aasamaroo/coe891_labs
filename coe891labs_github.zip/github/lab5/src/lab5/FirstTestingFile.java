package lab5;

import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;

public class FirstTestingFile {
  
	public String baseUrl = "http://demo.guru99.com/test/newtours/";
	String driverPath = "geckodriver";
	public WebDriver driver;
	public String expected = null;
	public String actual = null;
	
  @BeforeTest
  public void launchBrowser(){
	  System.out.println("Launching Firefox\n");
	  System.setProperty("webdriver.gecko.driver", driverPath);
	  driver = new FirefoxDriver();
	  driver.get(baseUrl);
  }
  
  @Test
  public void verifyHomepageTitle() {
	  String expectedTitle = "Welcome: Mercury Tours";
	  String actualTitle = driver.getTitle();
	  Assert.assertEquals(actualTitle, expectedTitle);
  }

  @AfterMethod
  public void goBackToHomepage() {
	  driver.findElement(By.linkText("Home")).click();
  }

 

  @AfterTest
  public void terminateBrowser() {
	  //driver.close();
  }
  


}
