package lab5;

import org.testng.Assert;
import org.testng.annotations.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;

public class Facebook {

	public String baseUrl = "http://www.facebook.com";
	String driverPath = "geckodriver";
	public WebDriver driver;
	public String expected = null;
	public String actual = null;
	
	@BeforeTest
	  public void launchBrowser(){
		  System.out.println("Launching Firefox\n");
		  System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get(baseUrl);
	  }
	
	@AfterTest
	  public void terminateBrowser() {
		  //driver.close();
	  }
	
	@Test
	  public void verifyEmailTag() {
		  expected = "input";
		  WebElement n = driver.findElement(By.id("email"));
		  String tagName = n.getTagName();
		  System.out.println("Tagname: " + tagName);
		  Assert.assertEquals(tagName, expected);
	  }
}
