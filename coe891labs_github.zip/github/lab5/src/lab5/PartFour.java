package lab5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import org.testng.Assert;

public class PartFour {
	
	public String baseUrl = "https://lambdatest.github.io/sample-todo-app";
	String driverPath = "geckodriver";
	public WebDriver driver;
	public String expected = null;
	public String actual = null;
	
	
	@BeforeTest
	  public void launchBrowser(){
		  System.out.println("Launching Firefox\n");
		  System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get(baseUrl);
	  }
	
	@Test(priority=0)
	public void checkSecondItem(){
		driver.findElement(By.name("li2")).click();
		try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);}
	}
	
	@Test(priority=1)
	public void checkFourthItem(){
		driver.findElement(By.name("li4")).click();
		try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);}
	}
	
	@Test(priority = 3)
	public void writeNameInBox(){
		WebElement p=driver.findElement(By.id("sampletodotext"));
		p.click();
	      //enter text with sendKeys() then apply submit()
	    p.sendKeys("Alex");
	    driver.findElement(By.id("addbutton")).click();
	    try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);}
	}
	
	@AfterTest
	  public void driverExit() {
		  //driver.close();
	  }
}
