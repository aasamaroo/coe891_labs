package lab5;

import org.testng.Assert;
import org.testng.annotations.*;

import java.time.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.*;
import org.openqa.selenium.support.ui.*;

public class PartFive {
	
	public String baseUrl = "http://www.google.com";
	String driverPath = "geckodriver";
	public WebDriver driver;
	public String expected = null;
	public String actual = null;
	
	@BeforeTest
	  public void openBrowser() {
		  System.out.println("Launching Firefox\n");
		  System.setProperty("webdriver.gecko.driver", driverPath);
		  driver = new FirefoxDriver();
		  driver.get(baseUrl);
	  }
	
	  @Test
	  public void performSearch() {
		  WebElement p=driver.findElement(By.name("q"));
	      //enter text with sendKeys() then apply submit()
	      p.sendKeys("Facebook");
	      WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(30));
	      w.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul")));
	      p.submit();
	      try{Thread.sleep(5000);}catch(InterruptedException e){System.out.println(e);} 
	  }
	  @AfterMethod
	  public void faceBookVerification() {
		   expected = "Facebook - Google Search";
		   actual = driver.getTitle();
		   Assert.assertEquals(expected, actual);
	  }
	  @AfterTest
	  public void driverExit() {
		  //driver.close();
	  }
}
