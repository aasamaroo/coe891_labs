package lab6;

import static org.junit.Assert.*;

import org.junit.Test;

public class LabSixTest {

	@Test
	public void testPali() {
		String s = "racecar";
		assertEquals(true, LabSix.isPalindrome(s));
	}
	@Test(expected = NullPointerException.class)
	public void testPaliPrimeTwo(){
		String s = null;
		LabSix.isPalindrome(s);	
	}
	
	@Test
	public void noLoopsAllowed(){
		int n = 1;
		LabSix.printPrimes(n);
	}
	
	@Test
	public void edgeCoverage(){
		int n = 47;
		LabSix.printPrimes(n);
	}

}
