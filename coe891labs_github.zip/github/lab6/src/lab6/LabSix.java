package lab6;

public class LabSix {
	
	public static boolean isPalindrome(String s) {
		if(s == null) {
			throw new NullPointerException();
		}
	int left = 0;
	int right = s.length() - 1;
	boolean result = true;
	while(left < right && result == true) {
		if(s.charAt(left) != s.charAt(right)) {
			result = false;
		}
		left ++;
		right --;
	}
	return result;
	}
	
	public static void printPrimes(int n) {
		int curPrime, numPrimes;
		boolean isPrime;
		int[] primes = new int[100];
		
		primes[0] = 2;
		numPrimes = 1;
		curPrime = 2;
		
		while (numPrimes < n) {
			curPrime++;
			isPrime = true;
			
			for (int i = 0; i <= numPrimes-1; i++) {
				if (isDivisible (primes[i], curPrime)) {
					isPrime = false;
					break;
				}
			}
			if (isPrime) {
				primes[numPrimes] = curPrime;
				numPrimes++;
			}
		}
		for (int i = 0; i <= numPrimes-1; i++) {
			System.out.println ("Prime: " + primes[i]);
		}
	}

	private static boolean isDivisible(int i, int curPrime) {
		if(i % curPrime == 0){
			return true;
		} else{
		return false;
		}
	}
}
