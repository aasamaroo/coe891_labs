package coe891_lab3;

public class Something {

	/**
	 * This is the program for Lab 3 Question 2
	 * @param a
	 * @param b
	 */
	
	public void func(int a, int b){
		if(b>a){
			b = b-a;
			System.out.println(b);
		} else if(a>b){
			a = a-b;
			System.out.println(a);
		} else {
			System.out.println(0);
		}
	}
	
	
}
