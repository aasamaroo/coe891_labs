package coe891_lab3;

import static org.junit.Assert.*;

import org.junit.*;

public class SomethingTest {

	private Something s;
	
	public SomethingTest(){
		
	}
	@BeforeClass
	public static void setUp(){
		System.out.println("Testing some function to see if we can get 100% Coverage");
	}
	
	@AfterClass
	public static void shutDown(){
		System.out.println("Tests completed");
	}
	
	@Before
	public void testPrep(){
		s = new Something();
	}
	
	@After
	public void testCleanUp(){
		s = null;
	}
	
	//Testing when b>a, this will go to the first block in the if statement
	@Test
	public void testFunc() {
		int a = 2;
		int b = 3;
		s.func(a, b);
	}
	
	//Testing when a>b, this will go to the else if statement in production code.
	@Test
	public void anotherTest(){
		int a = 3;
		int b = 2;
		s.func(a, b);
	}
	
	//Testing when a = b. This should result in 100% coverage.
	@Test
	public void whyNotAnotherTest(){
		int a = 3;
		int b = 3;
		s.func(a, b);
	}

}
